const router = require('express').Router();
const scheduleController = require('../controllers/schedule.controller');
const authMiddleware = require('../middlewares/auth.middleware');

/** Coach Side Routes */
// Get approved schedules for coach
router.get('/my-schedules', authMiddleware, scheduleController.getMySchedules);
// Get Pending Schedule (ADMIN)
router.get('/all-pending', authMiddleware, scheduleController.getPendingSchedules)

// Create new schedule request
router.post('/create', authMiddleware, scheduleController.createScheduleRequest);

// Edit schedule request
router.put('/coach/:id', authMiddleware, scheduleController.updateCoachSchedule);

// Delete schedule request
router.delete('/coach/:id', authMiddleware, scheduleController.deleteCoachSchedule);

module.exports = router;