import React, { useState, useEffect } from "react";
import Navbar from "../../GuestComponents/NavBar";
import Footer from "../../GuestComponents/Footer";
import api from "../../Services/api";



const generateTimeSlots = () => {
    const slots = [];
    for (let h = 6; h < 18; h += 2) {
        const fromHour = h % 12 === 0 ? 12 : h % 12;
        const toHour = (h + 2) % 12 === 0 ? 12 : (h + 2) % 12;
        const from = `${fromHour}:00 ${h < 12 ? "AM" : "PM"}`;
        const to = `${toHour}:00 ${(h + 2) < 12 ? "AM" : "PM"}`;
        slots.push(`${from} - ${to}`);
    }
    return slots;
};

const timeSlots = generateTimeSlots();

const typeColor = {
    Practice: "bg-blue-400",
    Match: "bg-green-400",
    Event: "bg-purple-400"
};

function Schedules() {
    const [venues, setVenues] = useState([]); 
    const [sports, setSports] = useState([]); 
    const [currentDate, setCurrentDate] = useState(new Date(2025, 10, 1));
    
    // FIX: Declare the missing state variable
    const [showSuccessModal, setShowSuccessModal] = useState(false); 

    const [formData, setFormData] = useState({
        name: "", email: "", role: "", universityId: "",
        sport_id: "", team_name: "", venue_id: "", date: "",
        timeSlot: "", event_name: "", additional_notes: ""
    });

    useEffect(() => {
        const loadData = async () => {
            try {
                const venueRes = await api.get("/venues");
                setVenues(venueRes.data);
                const sportRes = await api.get("/sports/approved");
                setSports(sportRes.data);
            } catch (error) {
                console.error("Error loading form data:", error);
            }
        };
        loadData();
    }, []);

    const handleChange = (e) =>
        setFormData({ ...formData, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Safety check for timeSlot split
        if (!formData.timeSlot.includes(" - ")) {
            return alert("Please select a valid time slot.");
        }

        const [rawStart, rawEnd] = formData.timeSlot.split(" - ");

        const formatTime = (timeStr) => {
            const [time, modifier] = timeStr.split(" ");
            let [hours, minutes] = time.split(":");
            if (hours === "12") {
                hours = modifier === "AM" ? "00" : "12";
            } else if (modifier === "PM") {
                hours = parseInt(hours, 10) + 12;
            }
            return `${String(hours).padStart(2, '0')}:${minutes}:00`;
        };

        const payload = {
            role: formData.role,
            user_name: formData.name, // Matches controller
            user_email: formData.email, // Matches controller
            university_id: formData.universityId,
            sport_id: formData.sport_id,
            venue_id: formData.venue_id,
            team_name: formData.team_name, 
            date: formData.date,
            start_time: formatTime(rawStart),
            end_time: formatTime(rawEnd),
            event_name: formData.event_name,
            additional_notes: formData.additional_notes
        };

        try {
            await api.post("/bookings", payload);
            setShowSuccessModal(true); 
            setFormData({
                name: "", email: "", role: "", universityId: "",
                sport_id: "", team_name: "", venue_id: "", date: "",
                timeSlot: "", event_name: "", additional_notes: ""
            });
        } catch (error) {
            console.error("Submission failed:", error.response?.data || error.message);
            alert("Error submitting request. Please check availability.");
        }
    };

    const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

    const monthName = currentDate.toLocaleString("default", { month: "long" });
    const year = currentDate.getFullYear();
    const daysInMonth = new Date(year, currentDate.getMonth() + 1, 0).getDate();
    const firstDayIndex = new Date(year, currentDate.getMonth(), 1).getDay();

    return (
        <div className="flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-grow pt-20 bg-gray-50">
                <div className="mx-auto max-w-7xl px-4">
                    <h1 className="text-3xl font-bold text-center mb-8">Schedules & Venue Booking</h1>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                        {/* BOOKING FORM */}
                        <div className="bg-white rounded-xl shadow p-6">
                            <h2 className="text-xl font-bold mb-4">Venue Booking Request</h2>
                            <form onSubmit={handleSubmit} className="space-y-3">
                                <input name="name" value={formData.name} required className="w-full border p-2 rounded" placeholder="Full Name" onChange={handleChange} />
                                <input name="email" value={formData.email} required type="email" className="w-full border p-2 rounded" placeholder="University Email" onChange={handleChange} />
                                
                                <select name="role" value={formData.role} required className="w-full border p-2 rounded" onChange={handleChange}>
                                    <option value="">Select Role</option>
                                    <option value="Student">Student</option>
                                    <option value="Coach">Coach</option>
                                    <option value="Staff">Staff</option>
                                </select>

                                {formData.role === "Student" && (
                                    <input name="universityId" value={formData.universityId} required className="w-full border p-2 rounded" placeholder="University ID" onChange={handleChange} />
                                )}

                                <select name="sport_id" value={formData.sport_id} required className="w-full border p-2 rounded" onChange={handleChange}>
                                    <option value="">Select Sport</option>
                                    {sports.map(s => <option key={s.sport_id} value={s.sport_id}>{s.sport_name}</option>)}
                                </select>

                                <input name="team_name" value={formData.team_name} required className="w-full border p-2 rounded" placeholder="Team Name" onChange={handleChange} />

                                <select name="venue_id" value={formData.venue_id} required className="w-full border p-2 rounded" onChange={handleChange}>
                                    <option value="">Select Venue</option>
                                    {venues.map(v => <option key={v.venue_id} value={v.venue_id}>{v.name} ({v.location})</option>)}
                                </select>

                                <input type="date" name="date" value={formData.date} required className="w-full border p-2 rounded" onChange={handleChange} />

                                <select name="timeSlot" value={formData.timeSlot} required className="w-full border p-2 rounded" onChange={handleChange}>
                                    <option value="">Select Time Slot</option>
                                    {timeSlots.map(t => <option key={t} value={t}>{t}</option>)}
                                </select>

                                <input name="event_name" value={formData.event_name} required className="w-full border p-2 rounded" placeholder="Purpose / Event Name" onChange={handleChange} />
                                <textarea name="additional_notes" value={formData.additional_notes} className="w-full border p-2 rounded" placeholder="Additional Notes" onChange={handleChange} />
                                
                                <button className="w-full bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700 transition">Submit Booking Request</button>
                            </form>
                        </div>

                        {/* CALENDAR */}
                        <div className="bg-white rounded-xl shadow p-6">
                            <div className="flex items-center justify-between mb-4">
                                <button onClick={prevMonth} className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">← Previous</button>
                                <h2 className="text-xl font-bold">{monthName} {year}</h2>
                                <button onClick={nextMonth} className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">Next →</button>
                            </div>
                            <div className="grid grid-cols-7 gap-2 text-center text-sm font-semibold text-gray-700">
                                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(d => <div key={d}>{d}</div>)}
                            </div>
                            <div className="grid grid-cols-7 gap-2 mt-2">
                                {Array.from({ length: firstDayIndex }).map((_, i) => <div key={`empty-${i}`} />)}
                                {Array.from({ length: daysInMonth }).map((_, i) => {
                                    const day = i + 1;
                                    return (
                                        <div key={day} className="h-24 border rounded-lg p-1 text-xs font-semibold">
                                            {day}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            {/* SUCCESS MODAL CODE BLOCK */}
            {showSuccessModal && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
                    <div className="bg-white rounded-2xl w-full max-w-sm p-8 text-center shadow-2xl animate-in zoom-in duration-200">
                        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">Request Submitted!</h2>
                        <p className="text-gray-600 mb-8">
                            Your booking request has been sent to the admin. You will receive an email confirmation once it is reviewed.
                        </p>
                        <button 
                            onClick={() => setShowSuccessModal(false)}
                            className="w-full bg-gray-900 text-white py-3 rounded-xl font-bold hover:bg-black transition shadow-lg"
                        >
                            Got it, thanks!
                        </button>
                    </div>
                </div>
            )}

            <Footer />
        </div>
    );
}

export default Schedules;
